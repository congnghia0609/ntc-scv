package vn.hus.nlp.tokenizer.web;

/**
 * @author LE HONG Phuong, phuonglh@gmail.com
 * <p>
 * Jul 7, 2009, 6:30:28 PM
 * <p>
 * Some predefined constants for use in the service.
 * 
 */
public interface IConstants {
	public static final int MAX_NUMBER_SESSIONS = 5;

}
