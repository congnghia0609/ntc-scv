package vn.hus.nlp.corpus;

/**
 * @author LE HONG Phuong, phuonglh@gmail.com
 * <br>
 * Jul 13, 2009, 12:07:57 PM
 * <br>
 * Some constants for use in the corpus.
 */
public interface IConstants {
	public static String PACKAGE_NAME = "vn.hus.nlp.corpus.jaxb";
}
