package vn.hus.nlp.lexicon;

public interface IConstants {
	public static String PACKAGE_NAME = "vn.hus.nlp.lexicon.jaxb";
}
